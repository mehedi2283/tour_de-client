website name: tourDE


live link: https://tourde-1a814.web.app/


* single page application
* loader used for loading state
* used mongoDB for database
* used email and google authentication for login
* home page shows only 3 services 


