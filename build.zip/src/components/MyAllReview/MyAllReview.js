import React from "react";
import { IoMdTrash, IoMdSave } from "react-icons/io";
import { Link } from "react-router-dom";
// import UpdateReviewWithModal from "../UpdateReviewWithModal/UpdateReviewWithModal";

const MyAllReviews = ({ review, handleDelete, modalClicked }) => {
  const { customer, email, message, serviceName, img, phone, _id } = review;

  return (
    <>
      <tr>
        <td>
          <div className="flex items-center space-x-3">
            <div className="avatar">
              <div className="mask mask-squircle w-12 h-12">
                <img src={img} alt="" />
              </div>
            </div>
            <div>
              <div className="font-bold text-primary">{customer}</div>
              <div className="text-sm opacity-50">{phone}</div>
            </div>
          </div>
        </td>
        <td>
          {message}
          <br />
          <span className="badge badge-primary badge-sm">{email}</span>
        </td>
        <td>{serviceName}</td>
        <th>
          <Link to={`/update_review/${_id}`}>
            <button className="btn bg-green-600 border-0 hover:text-green-900 text-white hover:bg-green-700">
              <IoMdSave className="text-3xl"></IoMdSave>
            </button>
          </Link>
        </th>
        <th>
          <button
            onClick={() => handleDelete(_id)}
            className="btn bg-red-600 border-0 hover:text-red-900 hover:bg-red-700"
          >
            <IoMdTrash className="text-3xl text-white "></IoMdTrash>
          </button>
        </th>

        {/* The button to open modal */}
       <th>
       <label htmlFor="my-modal-3" onClick={ () => modalClicked(_id) } className="btn bg-green-600 border-0  text-white hover:bg-green-700">
          Update
        </label>
       </th>
       
      </tr>

      {/* <hr /> */}
    </>
  );
};

export default MyAllReviews;
